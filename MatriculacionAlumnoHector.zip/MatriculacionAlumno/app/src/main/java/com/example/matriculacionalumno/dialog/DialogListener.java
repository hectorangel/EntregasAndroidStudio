package com.example.matriculacionalumno.dialog;

public interface DialogListener {

    interface ListenerEditar{
        void onClickEditar(Object o);
    }

    interface ListenerNueva{
        void onClickNueva(Object o);
    }
}

